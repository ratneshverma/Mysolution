﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondSolution.Interface
{
    internal interface IPromotionEngineManager
    {
        void GetInput();

        int GetTotaalPrice();

    }
}
